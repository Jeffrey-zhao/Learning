﻿//后台
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication4
{
    ///<summary>
    /// MainWindow.xaml 的交互逻辑
    ///</summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            int i, j, k; //定义三个变量
            for (i = 1; i <= 3; i++) //循环次数
            {
                for (j = 1; j <= 10; j++)
                {

                    this.Top += 1;
                    this.Left += 1;
                    System.Threading.Thread.Sleep(3); //当前线程指定挂起的时间
                }
                for (k = 1; k <= 10; k++)
                {
                    this.Top -= 1;
                    this.Left -= 1;
                    System.Threading.Thread.Sleep(3);
                }
            }
        }
    }
}