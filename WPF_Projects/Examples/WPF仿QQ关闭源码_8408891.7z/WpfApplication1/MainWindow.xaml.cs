﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        System.Windows.Media.Animation.Storyboard std = null;
        public MainWindow()
        {
            InitializeComponent();
            std = (System.Windows.Media.Animation.Storyboard)layoutroot.Resources["std"];
            std.Completed += (t, r) => this.Close();
            this.layoutroot.Loaded += (sd, ee) =>
            {
                // 设置Grid的圆形剪辑的圆心和半径
                EllipseGeometry eg = (EllipseGeometry)this.layoutroot.Clip;
                double dx = layoutroot.ActualWidth / 2d;
                double dy = layoutroot.ActualHeight / 2d;
                eg.Center = new Point(dx, dy);
                eg.RadiusX = dx;
                eg.RadiusY = dy;
            };

        }

        private void OnClick(object sender, RoutedEventArgs e)
        {
            if (std != null)
            {
                std.Begin();
            }
        }
    }
}
