﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TimeZoneDaemonApp
{
    /// <summary>
    /// WeatherWindow.xaml 的交互逻辑
    /// </summary>
    /// 
    public delegate string[] GetWeatherDaemonDelegate();
    public partial class WeatherWindow : MyMacClass
    {
        public WeatherWindow()
        {
            InitializeComponent();
        }
        public WeatherWindow(string[] WeatherList)
        {
            InitializeComponent();
            weatherList = WeatherList;
            if (weatherList != null)
            {
                if (weatherList.Length > 0)
                {
                    this.Title = weatherList[1];
                }
            }
        }

        private string[] weatherList;
        public event GetWeatherDaemonDelegate GetWeatherDaemonEvent;
    }
}
