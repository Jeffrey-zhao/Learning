﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Temperature
{
    public class AddBfh : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            float f = (float)value;
            return string.Format("{0}℃", f);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class Temp : Button
    {
        static Temp()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Temp), new FrameworkPropertyMetadata(typeof(Temp)));
        }

        #region 基本控件
        TextBlock txtMaxValue = null;
        TextBlock txtMinValue = null;
        TextBlock txtCurrentValue = null;
        TextBlock txtPosition = null;
        Rectangle rect = null;
        #endregion

        #region 设置绑定
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            AddBfh addBfh = new AddBfh();
            txtMaxValue = GetTemplateChild("MaxValue") as TextBlock;
            txtMinValue = GetTemplateChild("MinValue") as TextBlock;
            txtCurrentValue = GetTemplateChild("CurrentValue") as TextBlock;
            txtPosition = GetTemplateChild("Positions") as TextBlock;
            rect = GetTemplateChild("RectValue") as Rectangle;

            txtMaxValue.SetBinding(TextBlock.TextProperty, new Binding("MaxValue") { Source = this, Converter = addBfh });
            txtMinValue.SetBinding(TextBlock.TextProperty, new Binding("MinValue") { Source = this, Converter = addBfh });
            txtCurrentValue.SetBinding(TextBlock.TextProperty, new Binding("CurrentValue") { Source = this, Converter = addBfh });
            txtPosition.SetBinding(TextBlock.TextProperty, new Binding("MeterPosition") { Source = this });
            rect.SetBinding(Rectangle.HeightProperty, new Binding("CurrentValue") { Source = this });
        }
        #endregion

        #region 最大值
        public float MaxValue
        {
            get { return (float)GetValue(MaxValueProperty); }
            set { SetValue(MaxValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MaxValue.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxValueProperty =
            DependencyProperty.Register("MaxValue", typeof(float), typeof(Temp), new PropertyMetadata(100.0f));
        #endregion

        #region 最小值
        public float MinValue
        {
            get { return (float)GetValue(MinValueProperty); }
            set { SetValue(MinValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MinValue.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MinValueProperty =
            DependencyProperty.Register("MinValue", typeof(float), typeof(Temp), new PropertyMetadata(0f));
        #endregion

        #region 当前值
        public float CurrentValue
        {
            get { return (float)GetValue(CurrentValueProperty); }
            set { SetValue(CurrentValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CurrentValue.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CurrentValueProperty =
            DependencyProperty.Register("CurrentValue", typeof(float), typeof(Temp), new PropertyMetadata(50f, CurrentValueChange));

        public static void CurrentValueChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            (d as Temp).StoryboardPlay(e);
        }

        protected void StoryboardPlay(DependencyPropertyChangedEventArgs e)
        {
            Storyboard sb = new Storyboard();
            DoubleAnimation da = new DoubleAnimation();
            da.To = double.Parse(e.NewValue.ToString());
            da.Duration = new Duration(TimeSpan.Parse("0:0:1"));
            rect.BeginAnimation(Rectangle.HeightProperty, da);
        }
        #endregion

        #region 位置信息
        public string MeterPosition
        {
            get { return (string)GetValue(MeterPositionProperty); }
            set { SetValue(MeterPositionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MeterPosition.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MeterPositionProperty =
            DependencyProperty.Register("MeterPosition", typeof(string), typeof(Temp), new PropertyMetadata("浴室"));
        #endregion
    }
}
